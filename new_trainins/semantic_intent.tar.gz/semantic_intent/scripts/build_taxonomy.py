"""Phase 2 — Intent taxonomy / policy audit.

Writes configs/intents.yaml: for each of the 57 intents, a description, the
action class (command vs help vs reject), its confusable siblings, and the
policy decisions that were ambiguous. Positive examples are pulled from the
real data so the config stays honest about what the label actually contains.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]

# family -> members. Members inside a family are the ones a classifier is most
# likely to swap. Every family is a minimal-pair / hard-negative generator.
FAMILIES = {
    "volume": ["Cmd.VolumeIncrease", "Cmd.VolumeDecrease", "Cmd.VolumeMute",
               "Cmd.VolumeUnmute", "Help_Volume"],
    "memory": ["Cmd.MemoryChange", "Help_ChangingMemories", "Help_MemoryOptions",
               "Help_Customize"],
    "streaming": ["Cmd.StreamingStart", "Cmd.StreamingStop", "Help_Accessories"],
    "transcribe": ["Cmd.TranscribeStart", "Help_Transcribe"],
    "translate": ["Cmd.TranslationStart", "Help_Translate"],
    "find": ["Cmd.FindMyPhone", "Help_FindMyHearingAids"],
    "battery": ["Cmd.BatteryLevel", "Help_Battery"],
    "reminders": ["reminders.add", "reminders.complete", "Help_Reminder"],
    "messages": ["Cmd.SendMessage", "Cmd.ListenMessage"],
    "activity": ["Cmd.ActivityWalk", "Cmd.ActivityRun", "Cmd.ActivityCycle",
                 "Cmd.ActivityStep", "Cmd.ActivityStand", "Cmd.ActivityExercise",
                 "Cmd.ActivityAerobics", "Cmd.ActivityCalories"],
    "health": ["Help_Health", "Help_HeartRate", "Help_HeartRateRecovery",
               "Help_ThriveScore"],
    "care": ["Help_CleanCare", "Help_InsertDevice", "Help_SelfCheck",
             "Help_DeviceSettings"],
    "remote": ["Help_RemoteProgramming", "Help_HearingCareAnywhereConnect",
               "Help_HearShare"],
    "features": ["Help_EdgeMode", "Help_MaskMode", "Help_IntelliVoice",
                 "Help_Tinnitus", "Help_WiCROS", "Help_DemoMode"],
    "app": ["Help_Home", "Help_AppSettings", "Help_WhatsNew",
            "Help_VoiceAssistant", "Help_Pairing"],
    "safety": ["Help_FallAlert"],
    "reject": ["Default Fallback Intent"],
}

DESCRIPTIONS = {
    "Cmd.VolumeIncrease": "User asks the aid to raise volume now.",
    "Cmd.VolumeDecrease": "User asks the aid to lower volume now.",
    "Cmd.VolumeMute": "User asks to silence the aids entirely.",
    "Cmd.VolumeUnmute": "User asks to restore sound after muting.",
    "Help_Volume": "User asks HOW volume works or how to adjust it, not to change it now.",
    "Cmd.MemoryChange": "Switch to a named or numbered program/memory now.",
    "Help_ChangingMemories": "How-to for switching programs.",
    "Help_MemoryOptions": "How to create/customize/geotag programs.",
    "Help_Customize": "How to personalize sound (equalizer, treble, noise).",
    "Cmd.StreamingStart": "Begin audio streaming to the aids now.",
    "Cmd.StreamingStop": "End audio streaming now.",
    "Help_Accessories": "How-to for TV streamers, remote mics and other accessories.",
    "Cmd.TranscribeStart": "Start live transcription now.",
    "Help_Transcribe": "How the transcribe feature works.",
    "Cmd.TranslationStart": "Start translation now, or translate a given phrase.",
    "Help_Translate": "How the translate feature works.",
    "Cmd.FindMyPhone": "Locate the user's phone.",
    "Help_FindMyHearingAids": "Locate a lost hearing aid / use the aid finder.",
    "Cmd.BatteryLevel": "Report current battery charge now.",
    "Help_Battery": "How-to about batteries: size, type, replacing, charging.",
    "reminders.add": "Create a reminder.",
    "reminders.complete": "Mark an existing reminder done.",
    "Help_Reminder": "How the reminder feature works.",
    "Cmd.SendMessage": "Record/compose and send a voice message.",
    "Cmd.ListenMessage": "Play back received messages.",
    "Cmd.ActivityWalk": "Log or query walking activity.",
    "Cmd.ActivityRun": "Log or query running activity.",
    "Cmd.ActivityCycle": "Log or query cycling activity.",
    "Cmd.ActivityStep": "Log or query step count / step goal.",
    "Cmd.ActivityStand": "Log or query standing time / stand goal.",
    "Cmd.ActivityExercise": "Log or query generic exercise/workout.",
    "Cmd.ActivityAerobics": "Log or query aerobics / cardio-dance activity.",
    "Cmd.ActivityCalories": "Query calories burned.",
    "Help_Health": "How-to for activity/health summaries and goals.",
    "Help_HeartRate": "How-to for the heart-rate feature.",
    "Help_HeartRateRecovery": "How-to for the heart-rate-recovery metric.",
    "Help_ThriveScore": "How-to for the engagement/brain/body score.",
    "Help_CleanCare": "Cleaning, wax guards, moisture, waterproofing.",
    "Help_InsertDevice": "How to physically insert/wear the aid.",
    "Help_SelfCheck": "Run or interpret a self-check / diagnose a faulty aid.",
    "Help_DeviceSettings": "Device-level settings and hardware troubleshooting.",
    "Help_RemoteProgramming": "Remote adjustments made by the audiologist.",
    "Help_HearingCareAnywhereConnect": "Connecting for remote care / cloud restore.",
    "Help_HearShare": "Sharing hearing data with a family member/caregiver.",
    "Help_EdgeMode": "The on-demand environmental-optimization mode.",
    "Help_MaskMode": "The mode that compensates for face masks.",
    "Help_IntelliVoice": "DNN speech-enhancement feature.",
    "Help_Tinnitus": "Tinnitus masker / stimulus feature.",
    "Help_WiCROS": "CROS/WiCROS single-sided-hearing system.",
    "Help_DemoMode": "App demo mode.",
    "Help_Home": "Generic 'how does this work' / home screen / getting started.",
    "Help_AppSettings": "App-level settings, caregiver and alert settings.",
    "Help_WhatsNew": "What changed in the new app version.",
    "Help_VoiceAssistant": "Third-party voice assistants.",
    "Help_Pairing": "Pairing aids with phone/app, Bluetooth.",
    "Help_FallAlert": "Fall detection and alert messages.",
    "Default Fallback Intent": "Anything outside the supported command space.",
}

# The ambiguous cases the plan (Section 4 / Phase 6) says must be decided
# BEFORE training. These are product-policy calls, written down so evaluation
# can be consistent.
POLICIES = [
    dict(id="P1-cmd-vs-help",
         question="Is 'how do I turn up the volume' a command or a how-to?",
         decision="Help_Volume. An interrogative how/what/where/why/can-I frame "
                  "means the user wants an explanation, not an action. Only an "
                  "imperative or a direct request for a state change is a Cmd.",
         rationale="Executing a volume change when the user only asked how it "
                   "works is a false execution, which the plan ranks as more "
                   "harmful than asking again."),
    dict(id="P2-bare-negation",
         question="What does 'don't make it louder' mean with no alternative given?",
         decision="Default Fallback Intent (no action).",
         rationale="A negated command with no stated alternative does not "
                   "identify an action. Mapping it to the opposite intent is "
                   "the exact shortcut the plan forbids in Section 8."),
    dict(id="P3-corrective-negation",
         question="What about 'not quieter, louder' / 'I said turn it down, not up'?",
         decision="The affirmed alternative wins (Cmd.VolumeIncrease / "
                  "Cmd.VolumeDecrease respectively).",
         rationale="A correction states a target action explicitly."),
    dict(id="P4-symptom-reports",
         question="Is 'I can barely hear' a volume increase?",
         decision="Cmd.VolumeIncrease.",
         rationale="Already present in the training data as such; it is the "
                   "dominant user phrasing and the action is low-risk and "
                   "trivially reversible."),
    dict(id="P5-other-device-volume",
         question="'Turn the TV down' / 'make the phone louder'?",
         decision="Near-OOD -> Default Fallback Intent, EXCEPT where the aid "
                  "controls the TV streamer, which the data labels Help_Accessories.",
         rationale="The aid must not silently reinterpret another device's "
                   "volume as its own."),
    dict(id="P6-activity-query-vs-log",
         question="'How far have I walked' vs 'start a walk' — one intent or two?",
         decision="One intent per activity type (the shipped taxonomy merges "
                  "log and query). Do not split.",
         rationale="Matches the existing label set; splitting would invalidate "
                   "the baseline comparison."),
    dict(id="P7-fallback-is-not-ood-eval",
         question="Does the Default Fallback Intent class cover OOD?",
         decision="No. It is a supervised reject class for anticipated "
                  "unsupported phrasings. OOD is measured separately on a "
                  "held-out suite that includes near-OOD.",
         rationale="Section 11 of the plan."),
]


def main() -> None:
    df = pd.read_csv(ROOT / "data" / "raw" / "en.csv")
    counts = df["intent"].value_counts().to_dict()

    fam_of = {}
    for fam, members in FAMILIES.items():
        for m in members:
            fam_of[m] = fam

    intents = {}
    for intent in sorted(counts):
        fam = fam_of.get(intent, "other")
        siblings = [m for m in FAMILIES.get(fam, []) if m != intent]
        sub = df[df["intent"] == intent]["text"]
        kind = ("reject" if intent == "Default Fallback Intent"
                else "command" if intent.startswith(("Cmd.", "reminders."))
                else "help")
        intents[intent] = dict(
            description=DESCRIPTIONS.get(intent, ""),
            kind=kind,
            family=fam,
            n_train_rows=int(counts[intent]),
            confusable_with=siblings,
            positive_examples=sub.sample(min(5, len(sub)), random_state=7).tolist(),
        )

    cfg = dict(
        n_intents=len(intents),
        families={k: v for k, v in FAMILIES.items()},
        policies=POLICIES,
        intents=intents,
    )
    out = ROOT / "configs" / "intents.yaml"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True,
                                  width=100))
    missing = [i for i in counts if i not in DESCRIPTIONS]
    print(f"wrote {out} — {len(intents)} intents, "
          f"{len(FAMILIES)} families, {len(POLICIES)} policies; "
          f"missing descriptions: {missing}")


if __name__ == "__main__":
    main()
