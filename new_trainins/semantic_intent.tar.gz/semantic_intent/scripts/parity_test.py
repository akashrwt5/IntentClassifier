"""Phase 21 — Python vs ONNX parity, and the INT8 quality delta.

Two separate questions, kept separate:
  1. NUMERICAL parity — does the ONNX graph reproduce the Python probabilities
     within tolerance on the same inputs?
  2. DECISION parity — does the safety gate reach the same accept/reject verdict?
Decision parity is the one that can break a product; a tiny numeric drift that
flips a borderline case is a real defect even if max|delta| looks small.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import onnxruntime as ort
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))
from calibration import margin_of  # noqa: E402
from pipeline import DATA, IntentModel  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def onnx_probs(sess, model, texts, max_len=64) -> np.ndarray:
    names = {i.name for i in sess.get_inputs()}
    if "input_ids" in names:
        tok = model.encoder.tok
        prefix = getattr(model.encoder, "prefix", "")
        enc = tok([prefix + t for t in texts], padding="max_length",
                  truncation=True, max_length=max_len, return_tensors="np")
        feeds = {"input_ids": enc["input_ids"].astype(np.int64),
                 "attention_mask": enc["attention_mask"].astype(np.int64)}
    else:
        inp = sess.get_inputs()[0]
        if "string" in inp.type:
            feeds = {inp.name: np.array(texts, dtype=object).reshape(-1, 1)}
        else:
            # graph starts at the embedding (reference encoder path — see
            # onnx/EXPORT_NOTE.txt); feed it what the encoder produces
            feeds = {inp.name: model.encoder.encode(texts).astype(np.float32)}
    out = sess.run(None, feeds)
    probs = next(o for o in out if getattr(o, "ndim", 0) == 2
                 and o.shape[1] == len(model.labels))
    return np.asarray(probs, dtype=np.float64)


def compare(model, sess, texts, tol=1e-4) -> dict:
    # The transformer export fuses temperature scaling into the graph; the
    # reference sklearn export cannot, so compare against uncalibrated Python
    # probabilities there. Comparing a calibrated tensor to an uncalibrated one
    # would report a huge delta that is a bookkeeping artefact, not a defect.
    graph_is_calibrated = any(i.name == "input_ids" for i in sess.get_inputs())
    p_py = model.probs(texts, calibrated=graph_is_calibrated)
    p_ox = onnx_probs(sess, model, texts)
    d = np.abs(p_py - p_ox)
    top_py, top_ox = p_py.argmax(1), p_ox.argmax(1)

    gate = model.gate
    def verdicts(p):
        conf, marg = p.max(1), margin_of(p)
        idx = p.argmax(1)
        return np.array([
            (idx[i] != gate.reject_index) and conf[i] >= gate.conf_threshold
            and marg[i] >= gate.margin_threshold for i in range(len(p))])
    v_py, v_ox = verdicts(p_py), verdicts(p_ox)

    return dict(n=len(texts),
                graph_includes_temperature=bool(graph_is_calibrated),
                max_abs_delta=float(d.max()),
                mean_abs_delta=float(d.mean()),
                p99_abs_delta=float(np.quantile(d, 0.99)),
                top1_agreement=float((top_py == top_ox).mean()),
                gate_agreement=float((v_py == v_ox).mean()),
                within_tolerance=bool(d.max() <= tol),
                tolerance=tol,
                disagreements=[
                    dict(text=texts[i], py=model.labels[top_py[i]],
                         onnx=model.labels[top_ox[i]],
                         py_conf=float(p_py[i].max()), onnx_conf=float(p_ox[i].max()))
                    for i in np.where(top_py != top_ox)[0][:15]])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="models/final")
    ap.add_argument("--onnx-dir", default="models/final/onnx")
    ap.add_argument("--tolerance", type=float, default=1e-4)
    ap.add_argument("--int8-tolerance", type=float, default=5e-2)
    args = ap.parse_args()

    model = IntentModel.load(ROOT / args.model)
    d = ROOT / args.onnx_dir

    # Parity inputs deliberately include the nasty suites, not just clean test.
    texts = []
    for f in ("test.csv", "hard_negative_test.csv", "negation_test.csv",
              "ood_test.csv", "stt_test.csv", "contextual_test.csv"):
        texts += pd.read_csv(DATA / f)["text"].tolist()[:400]

    report = {}
    for tag, fname, tol in (("fp32", "intent_fp32.onnx", args.tolerance),
                            ("int8", "intent_int8.onnx", args.int8_tolerance)):
        p = d / fname
        if not p.exists():
            continue
        sess = ort.InferenceSession(str(p), providers=["CPUExecutionProvider"])
        r = compare(model, sess, texts, tol)
        r["size_mb"] = round(p.stat().st_size / 1e6, 3)
        report[tag] = r
        status = "PASS" if r["within_tolerance"] else "OUT OF TOLERANCE"
        print(f"[{tag}] {status}  max|d|={r['max_abs_delta']:.3e} "
              f"top1_agree={r['top1_agreement']:.5f} "
              f"gate_agree={r['gate_agreement']:.5f} size={r['size_mb']}MB")
        if r["disagreements"]:
            print(f"      {len(r['disagreements'])} shown top-1 disagreements, "
                  f"first: {r['disagreements'][0]}")

    (ROOT / "reports" / "parity.json").write_text(json.dumps(report, indent=2))
    print("-> reports/parity.json")


if __name__ == "__main__":
    main()
