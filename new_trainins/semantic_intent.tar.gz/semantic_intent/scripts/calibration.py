"""Phases 15-20 — calibration, calibration metrics, threshold + margin gate.

Nothing here is allowed to look at the final test set. Every parameter
(temperature, confidence threshold, margin threshold) is fitted on the
validation split only.
"""
from __future__ import annotations

import numpy as np


# ---------------------------------------------------------------------------
# Temperature scaling
# ---------------------------------------------------------------------------
def softmax(z: np.ndarray) -> np.ndarray:
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def nll(logits: np.ndarray, y: np.ndarray, T: float) -> float:
    p = softmax(logits / T)
    return float(-np.log(np.clip(p[np.arange(len(y)), y], 1e-12, None)).mean())


def fit_temperature(logits: np.ndarray, y: np.ndarray,
                    lo: float = 0.05, hi: float = 10.0,
                    iters: int = 60) -> float:
    """Golden-section search on NLL. Deterministic, no optimizer dependency."""
    phi = (np.sqrt(5) - 1) / 2
    a, b = lo, hi
    c, d = b - phi * (b - a), a + phi * (b - a)
    fc, fd = nll(logits, y, c), nll(logits, y, d)
    for _ in range(iters):
        if fc < fd:
            b, d, fd = d, c, fc
            c = b - phi * (b - a)
            fc = nll(logits, y, c)
        else:
            a, c, fc = c, d, fd
            d = a + phi * (b - a)
            fd = nll(logits, y, d)
    return float((a + b) / 2)


# ---------------------------------------------------------------------------
# Calibration metrics
# ---------------------------------------------------------------------------
def reliability(conf: np.ndarray, correct: np.ndarray, n_bins: int = 10):
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    rows = []
    for i in range(n_bins):
        lo, hi = edges[i], edges[i + 1]
        m = (conf > lo) & (conf <= hi) if i else (conf >= lo) & (conf <= hi)
        if m.sum() == 0:
            rows.append(dict(bin_lo=lo, bin_hi=hi, n=0, avg_conf=np.nan,
                             accuracy=np.nan, gap=np.nan))
            continue
        rows.append(dict(bin_lo=float(lo), bin_hi=float(hi), n=int(m.sum()),
                         avg_conf=float(conf[m].mean()),
                         accuracy=float(correct[m].mean()),
                         gap=float(conf[m].mean() - correct[m].mean())))
    return rows


def ece(conf: np.ndarray, correct: np.ndarray, n_bins: int = 10) -> float:
    rows = reliability(conf, correct, n_bins)
    n = len(conf)
    return float(sum(r["n"] / n * abs(r["gap"]) for r in rows if r["n"]))


def mce(conf: np.ndarray, correct: np.ndarray, n_bins: int = 10) -> float:
    rows = reliability(conf, correct, n_bins)
    gaps = [abs(r["gap"]) for r in rows if r["n"] >= 10]
    return float(max(gaps)) if gaps else float("nan")


def brier(probs: np.ndarray, y: np.ndarray) -> float:
    onehot = np.zeros_like(probs)
    onehot[np.arange(len(y)), y] = 1.0
    return float(((probs - onehot) ** 2).sum(axis=1).mean())


# ---------------------------------------------------------------------------
# Operating point selection
# ---------------------------------------------------------------------------
def margin_of(probs: np.ndarray) -> np.ndarray:
    part = np.partition(probs, -2, axis=1)
    return part[:, -1] - part[:, -2]


def select_operating_point(probs: np.ndarray, y: np.ndarray,
                           target_precision: float = 0.97,
                           min_coverage: float = 0.50,
                           margin_grid=(0.0, 0.05, 0.10, 0.15, 0.20, 0.30, 0.40)):
    """Smallest gate that reaches `target_precision` on accepted predictions
    while keeping coverage >= min_coverage. Precision-first, per Phase 17:
    a false execution on a hearing aid is worse than asking again."""
    pred = probs.argmax(1)
    conf = probs.max(1)
    marg = margin_of(probs)
    correct = (pred == y)

    best = None
    for m_thr in margin_grid:
        for c_thr in np.round(np.arange(0.20, 0.995, 0.005), 3):
            acc_mask = (conf >= c_thr) & (marg >= m_thr)
            n_acc = int(acc_mask.sum())
            if n_acc == 0:
                continue
            precision = float(correct[acc_mask].mean())
            coverage = n_acc / len(y)
            if precision >= target_precision and coverage >= min_coverage:
                cand = dict(conf_threshold=float(c_thr), margin_threshold=float(m_thr),
                            precision=precision, coverage=coverage, n_accepted=n_acc)
                if best is None or cand["coverage"] > best["coverage"]:
                    best = cand
    if best is None:  # target unreachable — report the best precision available
        rows = []
        for m_thr in margin_grid:
            for c_thr in np.round(np.arange(0.20, 0.995, 0.005), 3):
                acc_mask = (conf >= c_thr) & (marg >= m_thr)
                if acc_mask.sum() < max(20, 0.05 * len(y)):
                    continue
                rows.append(dict(conf_threshold=float(c_thr),
                                 margin_threshold=float(m_thr),
                                 precision=float(correct[acc_mask].mean()),
                                 coverage=float(acc_mask.mean()),
                                 n_accepted=int(acc_mask.sum())))
        rows.sort(key=lambda r: (-r["precision"], -r["coverage"]))
        best = rows[0] if rows else dict(conf_threshold=0.5, margin_threshold=0.0,
                                         precision=float("nan"), coverage=1.0,
                                         n_accepted=len(y))
        best["target_met"] = False
    else:
        best["target_met"] = True
    best["target_precision"] = target_precision
    return best


def coverage_precision_curve(probs, y, margin_threshold=0.0):
    pred, conf = probs.argmax(1), probs.max(1)
    marg = margin_of(probs)
    correct = (pred == y)
    out = []
    for c in np.round(np.arange(0.3, 1.0, 0.05), 2):
        m = (conf >= c) & (marg >= margin_threshold)
        if m.sum() == 0:
            continue
        out.append(dict(threshold=float(c), coverage=float(m.mean()),
                        precision=float(correct[m].mean()),
                        n=int(m.sum())))
    return out


# ---------------------------------------------------------------------------
# The runtime safety gate (Phase 20)
# ---------------------------------------------------------------------------
class SafetyGate:
    def __init__(self, conf_threshold: float, margin_threshold: float,
                 labels: list[str], reject_label: str = "Default Fallback Intent",
                 temperature: float = 1.0):
        self.conf_threshold = conf_threshold
        self.margin_threshold = margin_threshold
        self.labels = labels
        self.reject_label = reject_label
        self.reject_index = labels.index(reject_label) if reject_label in labels else -1
        self.temperature = temperature

    def decide(self, logits: np.ndarray) -> list[dict]:
        probs = softmax(logits / self.temperature)
        order = np.argsort(-probs, axis=1)
        results = []
        for i in range(len(probs)):
            i1, i2 = order[i, 0], order[i, 1]
            c1, c2 = float(probs[i, i1]), float(probs[i, i2])
            m = c1 - c2
            if i1 == self.reject_index:
                accepted, reason = False, "classified as unsupported"
            elif c1 < self.conf_threshold:
                accepted, reason = False, "below calibrated confidence threshold"
            elif m < self.margin_threshold:
                accepted, reason = False, "top-1/top-2 margin too small"
            else:
                accepted, reason = True, "above calibrated threshold"
            results.append(dict(intent=self.labels[i1], confidence=round(c1, 4),
                                top2_intent=self.labels[i2], top2_score=round(c2, 4),
                                margin=round(m, 4), accepted=accepted, reason=reason))
        return results

    def to_dict(self) -> dict:
        return dict(conf_threshold=self.conf_threshold,
                    margin_threshold=self.margin_threshold,
                    temperature=self.temperature,
                    reject_label=self.reject_label,
                    labels=self.labels)
