"""Phase 17/23 — targeted dataset iteration.

Every block here exists because a specific suite failed, not because more data
is generally nice. Generated items are filtered against the leakage keys of
validation, test AND every challenge suite, so nothing we add can leak into
what we measure on.

Failure modes addressed:
  F1  negation      — the model never saw the P2/P3 policy at training time
  F2  direction     — up/down, mute/unmute, start/stop under paraphrase
  F3  cmd_vs_help   — imperative vs interrogative frame on the same content
  F4  near_ood      — another device's volume must not become an aid command
  F5  stt           — offline ASR artifacts on real training sentences
  F6  tail classes  — 13 intents have fewer than 60 examples
"""
from __future__ import annotations

import itertools
import random
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))
from build_challenge_sets import stt_corrupt  # noqa: E402
from common import leakage_key, normalize  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FALLBACK = "Default Fallback Intent"
SEED = 99

# --- F1 negation ------------------------------------------------------------
NEG_OPENERS = ["do not", "don't", "please do not", "i do not want you to",
               "i did not ask you to", "no need to", "there is no need to",
               "stop trying to", "i never asked you to"]
NEG_ACTIONS = {
    "turn it up": "Cmd.VolumeIncrease", "turn it down": "Cmd.VolumeDecrease",
    "make it louder": "Cmd.VolumeIncrease", "make it quieter": "Cmd.VolumeDecrease",
    "raise the volume": "Cmd.VolumeIncrease", "lower the volume": "Cmd.VolumeDecrease",
    "mute the aids": "Cmd.VolumeMute", "unmute the aids": "Cmd.VolumeUnmute",
    "switch my program": "Cmd.MemoryChange", "change my memory": "Cmd.MemoryChange",
    "start streaming": "Cmd.StreamingStart", "stop streaming": "Cmd.StreamingStop",
    "set a reminder": "reminders.add", "send a message": "Cmd.SendMessage",
    "play my messages": "Cmd.ListenMessage", "start translating": "Cmd.TranslationStart",
    "start transcribing": "Cmd.TranscribeStart", "find my phone": "Cmd.FindMyPhone",
}
CORRECTIVE = [  # (wrong_action, right_action, right_intent)
    ("quieter", "louder", "Cmd.VolumeIncrease"),
    ("louder", "quieter", "Cmd.VolumeDecrease"),
    ("down", "up", "Cmd.VolumeIncrease"),
    ("up", "down", "Cmd.VolumeDecrease"),
    ("muted", "unmuted", "Cmd.VolumeUnmute"),
    ("unmuted", "muted", "Cmd.VolumeMute"),
    ("stopped", "started", "Cmd.StreamingStart"),
    ("started", "stopped", "Cmd.StreamingStop"),
]
CORRECTIVE_FRAMES = [
    "not {w}, {r}", "i said {r}, not {w}", "no, {r} not {w}",
    "{r} please, not {w}", "i wanted it {r}, not {w}",
]

# --- F2 direction -----------------------------------------------------------
DIRECTION_FRAMES = [
    ("could you {v} the sound", "{v} the sound"),
]
UP_VERBS = ["raise", "lift", "increase", "boost", "step up", "pump up",
            "bring up", "push up", "turn up", "crank up", "amplify"]
DOWN_VERBS = ["lower", "reduce", "decrease", "soften", "step down", "bring down",
              "push down", "turn down", "dial down", "damp down", "cut back"]
UP_FRAMES = ["{v} the volume", "can you {v} the volume", "{v} my hearing aids",
             "{v} the sound a bit", "please {v} the level", "{v} it a little",
             "would you {v} the volume for me", "{v} the audio please"]
OBJ_SWAP = {"the volume": "the sound", "my hearing aids": "my aids"}

# --- F3 cmd vs help ---------------------------------------------------------
CMD_HELP = [
    # (imperative, cmd_intent, interrogative, help_intent)
    ("{v} the volume", "VOL", "how do i {v} the volume", "Help_Volume"),
    ("{v} the volume", "VOL", "where do i {v} the volume", "Help_Volume"),
    ("{v} the volume", "VOL", "can you show me how to {v} the volume", "Help_Volume"),
    ("{v} the volume", "VOL", "what is the way to {v} the volume", "Help_Volume"),
]
MEMORY_TARGETS = ["restaurant", "outdoor", "car", "church", "party", "office",
                  "tv", "music", "quiet", "windy", "meeting"]
MEM_CMD = ["switch to the {m} program", "put me on the {m} setting",
           "change to {m} mode", "go to my {m} memory", "use the {m} program"]
MEM_HELP = ["how do i switch to the {m} program", "how do i get to the {m} setting",
            "where do i find the {m} program", "explain how to use the {m} memory"]

# --- F4 near OOD ------------------------------------------------------------
OTHER_DEVICES = ["television", "tv set", "phone", "mobile", "radio", "laptop",
                 "speaker", "car stereo", "tablet", "alarm clock", "doorbell"]
OOD_FRAMES = ["turn the {d} volume up", "turn the {d} volume down",
              "mute the {d}", "make the {d} louder", "make the {d} quieter",
              "increase the {d} brightness", "pause the {d}"]


def gen_negation(rng) -> list[dict]:
    rows = []
    # P2: bare negation -> no action
    for opener, action in itertools.product(NEG_OPENERS, NEG_ACTIONS):
        rows.append(dict(text=f"{opener} {action}", intent=FALLBACK,
                         source="F1_negation_bare"))
    # P3: corrective -> affirmed action wins
    for (w, r, intent), frame in itertools.product(CORRECTIVE, CORRECTIVE_FRAMES):
        rows.append(dict(text=frame.format(w=w, r=r), intent=intent,
                         source="F1_negation_corrective"))
    # P3 variant with an explicit second clause
    for opener, (w, r, intent) in itertools.product(NEG_OPENERS[:5], CORRECTIVE):
        rows.append(dict(text=f"{opener} make it {w}, make it {r}",
                         intent=intent, source="F1_negation_corrective"))
    rng.shuffle(rows)
    return rows


def gen_direction(rng) -> list[dict]:
    rows = []
    for verbs, intent in ((UP_VERBS, "Cmd.VolumeIncrease"),
                          (DOWN_VERBS, "Cmd.VolumeDecrease")):
        for v, frame in itertools.product(verbs, UP_FRAMES):
            t = frame.format(v=v)
            rows.append(dict(text=t, intent=intent, source="F2_direction"))
            for a, b in OBJ_SWAP.items():
                if a in t:
                    rows.append(dict(text=t.replace(a, b), intent=intent,
                                     source="F2_direction"))
    # symptom -> action, both directions, matched frames
    for a, b in [("i can hardly hear anything", "everything is deafening"),
                 ("this is far too faint", "this is far too harsh"),
                 ("the speech is too weak", "the speech is too strong"),
                 ("sounds are coming through very thin", "sounds are coming through very heavy")]:
        rows.append(dict(text=a, intent="Cmd.VolumeIncrease", source="F2_direction"))
        rows.append(dict(text=b, intent="Cmd.VolumeDecrease", source="F2_direction"))
    # mute / unmute and start / stop
    for t, i in [("switch the sound off for now", "Cmd.VolumeMute"),
                 ("switch the sound on again", "Cmd.VolumeUnmute"),
                 ("no sound at all please", "Cmd.VolumeMute"),
                 ("give me sound again please", "Cmd.VolumeUnmute"),
                 ("put the audio through to my aids", "Cmd.StreamingStart"),
                 ("take the audio off my aids", "Cmd.StreamingStop"),
                 ("open the audio link", "Cmd.StreamingStart"),
                 ("close the audio link", "Cmd.StreamingStop")]:
        rows.append(dict(text=t, intent=i, source="F2_direction"))
    rng.shuffle(rows)
    return rows


def gen_cmd_help(rng) -> list[dict]:
    rows = []
    for v, intent in ([(v, "Cmd.VolumeIncrease") for v in UP_VERBS]
                      + [(v, "Cmd.VolumeDecrease") for v in DOWN_VERBS]):
        for cmd_f, _, help_f, help_i in CMD_HELP:
            rows.append(dict(text=cmd_f.format(v=v), intent=intent,
                             source="F3_cmd_vs_help"))
            rows.append(dict(text=help_f.format(v=v), intent=help_i,
                             source="F3_cmd_vs_help"))
    for m in MEMORY_TARGETS:
        for f in MEM_CMD:
            rows.append(dict(text=f.format(m=m), intent="Cmd.MemoryChange",
                             source="F3_cmd_vs_help"))
        for f in MEM_HELP:
            rows.append(dict(text=f.format(m=m), intent="Help_ChangingMemories",
                             source="F3_cmd_vs_help"))
    rng.shuffle(rows)
    return rows


def gen_near_ood(rng) -> list[dict]:
    rows = [dict(text=f.format(d=d), intent=FALLBACK, source="F4_near_ood")
            for d, f in itertools.product(OTHER_DEVICES, OOD_FRAMES)]
    rng.shuffle(rows)
    return rows


def gen_stt_augmentation(train: pd.DataFrame, rng, per_row: int = 1) -> list[dict]:
    rows = []
    srng = random.Random(SEED + 5)
    for _, r in train.iterrows():
        for _ in range(per_row):
            c, ops = stt_corrupt(normalize(r["text"]), srng)
            if c != normalize(r["text"]):
                rows.append(dict(text=c, intent=r["intent"],
                                 source=f"F5_stt:{ops}"))
    rng.shuffle(rows)
    return rows


def main() -> None:
    rng = random.Random(SEED)
    train = pd.read_csv(DATA / "train.csv")

    # forbidden keys: anything we evaluate on
    forbidden_keys, forbidden_norm = set(), set()
    for f in ["validation.csv", "test.csv", "hard_negative_test.csv",
              "ood_test.csv", "minimal_pair_test.csv", "negation_test.csv",
              "contextual_test.csv", "stt_test.csv"]:
        d = pd.read_csv(DATA / f)
        forbidden_keys |= set(d["text"].map(leakage_key))
        forbidden_norm |= set(d["text"].map(normalize))

    blocks = {
        "F1_negation": gen_negation(rng),
        "F2_direction": gen_direction(rng),
        "F3_cmd_vs_help": gen_cmd_help(rng),
        "F4_near_ood": gen_near_ood(rng),
        "F5_stt": gen_stt_augmentation(train, rng),
    }

    kept, dropped = [], 0
    seen = set(train["text"].map(normalize))
    for name, rows in blocks.items():
        n_before = len(rows)
        for r in rows:
            n, k = normalize(r["text"]), leakage_key(r["text"])
            if n in forbidden_norm or k in forbidden_keys or n in seen:
                dropped += 1
                continue
            seen.add(n)
            kept.append(r)
        print(f"{name:16s} generated={n_before:5d} kept={sum(1 for r in kept if r['source'].startswith(name.split('_')[0])):5d}")

    aug = pd.DataFrame(kept)
    aug.to_csv(DATA / "targeted_augmentation.csv", index=False)

    combined = pd.concat([
        train.assign(source="original"),
        aug[["text", "intent", "source"]],
    ], ignore_index=True)
    combined.to_csv(DATA / "train_augmented.csv", index=False)

    # final safety check
    ck = set(combined["text"].map(leakage_key)) & forbidden_keys
    cn = set(combined["text"].map(normalize)) & forbidden_norm
    print(f"\naugmented train: {len(train)} -> {len(combined)} "
          f"(+{len(aug)}), dropped {dropped} colliding")
    print(f"VERIFY leakage against all eval suites: keys={len(ck)} norm={len(cn)} (expect 0/0)")
    assert not ck and not cn
    print(combined["source"].str.split(":").str[0].value_counts().to_string())


if __name__ == "__main__":
    main()
