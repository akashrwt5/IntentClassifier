"""Phase 14 + 18 — train, calibrate, gate and freeze one candidate.

    python scripts/train_classifier.py --encoder tfidf-svd --classifier mlp \
        --train train_augmented --out models/final

Calibration temperature and both gate thresholds come from the validation
split only. The test split is touched exactly once, by evaluate/report.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))
from calibration import (SafetyGate, coverage_precision_curve, ece,  # noqa: E402
                         fit_temperature, select_operating_point, softmax)
from encoders import get_encoder, measure_latency  # noqa: E402
from evaluate_model import headline, run_all  # noqa: E402
from pipeline import DATA, IntentModel  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--encoder", default="tfidf-svd")
    ap.add_argument("--classifier", default="mlp")
    ap.add_argument("--train", default="train_augmented")
    ap.add_argument("--out", default="models/final")
    ap.add_argument("--target-precision", type=float, default=0.97)
    ap.add_argument("--min-coverage", type=float, default=0.50)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    train = pd.read_csv(DATA / f"{args.train}.csv")
    val = pd.read_csv(DATA / "validation.csv")

    model = IntentModel(get_encoder(args.encoder), args.classifier, seed=args.seed)
    model.fit(train["text"], train["intent"])
    print(f"fitted {args.encoder} + {args.classifier} on {len(train)} rows "
          f"in {model.fit_seconds}s; {len(model.labels)} classes")

    logits_va = model.logits(val["text"].tolist())
    yva = model.y_index(val["intent"].tolist())
    ece_raw = ece(softmax(logits_va).max(1), softmax(logits_va).argmax(1) == yva)
    T = fit_temperature(logits_va, yva)
    model.temperature = T
    p_cal = softmax(logits_va / T)
    ece_cal = ece(p_cal.max(1), p_cal.argmax(1) == yva)
    print(f"temperature={T:.4f}  ECE {ece_raw:.4f} -> {ece_cal:.4f}")

    op = select_operating_point(p_cal, yva, args.target_precision, args.min_coverage)
    model.gate = SafetyGate(op["conf_threshold"], op["margin_threshold"],
                            model.labels, temperature=T)
    print(f"gate: conf>={op['conf_threshold']} margin>={op['margin_threshold']} "
          f"-> val precision={op['precision']:.4f} coverage={op['coverage']:.4f} "
          f"target_met={op['target_met']}")

    out = ROOT / args.out
    model.save(out)

    curve = coverage_precision_curve(p_cal, yva, op["margin_threshold"])
    (ROOT / "reports" / "operating_point.json").write_text(json.dumps(
        dict(temperature=T, ece_raw=ece_raw, ece_calibrated=ece_cal,
             operating_point=op, coverage_precision_curve=curve), indent=2))

    res = run_all(model)
    (ROOT / "reports" / "final_suites.json").write_text(
        json.dumps(res, indent=2, default=float))
    print(headline(res))
    lat = measure_latency(model.encoder, val["text"].tolist())
    print(f"encoder latency p50={lat['p50_ms']}ms p90={lat['p90_ms']}ms")
    print(f"saved -> {out}")


if __name__ == "__main__":
    main()
