# semantic_intent — offline hearing-aid intent classifier

Implements the robustness & trustworthy-confidence plan for the **57-intent**
English command set in `data/raw/en.csv`.

## Status

| plan step | state |
|---|---|
| 1 Dataset audit | done — `reports/dataset_audit.md` |
| 2 Intent taxonomy / policy | done — `configs/intents.yaml` (57 intents, 17 families, 7 policy decisions) |
| 3 Clean duplicates + leakage | done — `data/cleaned/dataset_clean.csv` |
| 4–9 Coverage, minimal pairs, hard negatives, negation, STT, OOD | done — `data/challenge/` |
| 10 Splits | done — leakage-verified, 0 shared keys/groups |
| 11 Encoder benchmark | **blocked** — needs local encoder weights (see below) |
| 12 Classifier benchmark | done — `reports/benchmark.md` |
| 13 Hard-negative + OOD eval | done |
| 14–15 Calibration | done — `reports/calibration.md` |
| 16 Threshold + margin | done |
| 17 Error analysis | done — `reports/error_analysis_*.md` |
| 18 Targeted iteration | done — `data/targeted_augmentation.csv` |
| 19–21 ONNX export, INT8, parity | done — `scripts/export_onnx.py`, `scripts/parity_test.py` |
| 22 Android integration | contract written — `reports/android_integration.md` |
| 23 Final evaluation | `reports/final_evaluation.md` |

### What is blocked and why

The container this was built in cannot reach `huggingface.co`, so E5-small /
MiniLM / BGE-small could not be downloaded. Everything downstream of the
encoder is finished and proven end to end against two working encoders:

- `tfidf-svd` — a real, offline reference encoder (word 1-2 grams + char 3-5
  grams -> 384-d SVD). It is a genuine accuracy floor, not a stub.
- `smoke-tinybert` — a locally-constructed 2-layer BERT with a corpus-trained
  WordPiece tokenizer, used to prove the transformer training -> ONNX export ->
  INT8 -> parity path works without a network.

To finish step 11, drop encoder folders into `models/encoders/`:

```text
models/encoders/e5-small-v2/        config.json, tokenizer*, model.safetensors
models/encoders/all-MiniLM-L6-v2/
models/encoders/bge-small-en-v1.5/
```

`scripts/encoders.py` auto-discovers any directory there containing a
`config.json`. Then:

```bash
python scripts/benchmark_classifiers.py --train train_augmented \
    --out reports/benchmark_encoders.json
```

## Run order

```bash
python scripts/audit_dataset.py            # phase 1
python scripts/build_taxonomy.py           # phase 2
python scripts/build_challenge_sets.py     # phases 4-9
python scripts/split_dataset.py            # phases 3 + 10
python scripts/build_targeted_training.py  # phase 17/23
python scripts/benchmark_classifiers.py --train train_augmented
python scripts/train_classifier.py --encoder <winner> --classifier <winner> \
       --train train_augmented --out models/final
python scripts/error_analysis.py models/final final
python scripts/export_onnx.py --model models/final --out models/final/onnx
python scripts/parity_test.py --model models/final --onnx-dir models/final/onnx
python scripts/make_reports.py
```

## Design decisions worth knowing

**Leakage control is group-based, not row-based.** Two sentences are put in the
same split if they share a normalized form, a content-word key, or score >=92
token_sort similarity within an intent. 9723 rows collapse into 5173 groups,
which means roughly half the corpus is near-duplicate material. A plain random
split would have measured memorization.

**Calibration is inside the ONNX graph, thresholds are outside.** Temperature
belongs with the weights it was fitted to. Thresholds are a product decision.

**The gate has three independent reasons to refuse** — reject class, confidence,
and top1-top2 margin. Margin catches the 0.51/0.48 case that confidence alone
calls a decision.

**Nothing is selected on a challenge suite.** Model selection uses validation
macro-F1 and validation ECE only. The challenge suites are reported for every
candidate so the failure modes are visible, but they never feed back into the
choice.

**The baseline comparison is not like-for-like.** The 0.236 MB INT8 student was
measured on 11 intents. This is 57 intents with a 35x class imbalance on a
leakage-controlled split. Re-run the baseline against these suites before
claiming either one wins.
